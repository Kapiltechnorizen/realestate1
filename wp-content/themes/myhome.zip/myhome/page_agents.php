<?php
/**
 * Template Name: Frontend Panel
 */

get_header();

?>
	<div class="mh-user-panel-wrapper">
		<div id="app"></div>
	</div>
<?php
get_footer();