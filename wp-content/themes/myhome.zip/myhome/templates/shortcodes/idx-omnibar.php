<div class="myhome-idx-omnibar">
	<?php echo do_shortcode( '[idx-omnibar styles="1" extra="0" min_price="0" ]' ); ?>
</div>