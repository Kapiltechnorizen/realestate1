<?php
global $myhome_idx_wrapper;
?>
<section
	id="myhome-idx-wrapper"
	class="<?php echo esc_attr( $myhome_idx_wrapper['class'] ); ?>"
>
	<div id="idxStart"></div>
	<div id="idxStop"></div>
</section>
