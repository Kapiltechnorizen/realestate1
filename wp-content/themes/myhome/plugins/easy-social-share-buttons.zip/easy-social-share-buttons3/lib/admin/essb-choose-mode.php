<?php
?>
<div class="wrap">
	<div class="essb-light-mode-message"><i class="fa fa-check-square-o  fa-lg"></i>&nbsp;&nbsp;<span><b>Easy Social Share Buttons for WordPress is running in Easy Mode</b></span></div>
</div>