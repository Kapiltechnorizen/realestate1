(function( $ ) {
    "use strict";

} )( jQuery );
