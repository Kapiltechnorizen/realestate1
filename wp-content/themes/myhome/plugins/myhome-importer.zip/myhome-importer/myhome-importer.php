<?php
/*
Plugin Name: MyHome Demo Importer
Description: This plugin adds possibility to load MyHome demo content
Version: 3.6
Plugin URI: https://myhometheme.net
 */
include_once 'includes/class-myhome-importer.php';
$myhome_importer = new My_Home_Importer();
